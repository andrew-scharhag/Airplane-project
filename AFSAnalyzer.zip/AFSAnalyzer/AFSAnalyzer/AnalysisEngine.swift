import AVFoundation
import Vision
import UIKit
import CoreImage

// MARK: - Analysis Engine

actor AnalysisEngine {

    enum AnalysisError: LocalizedError {
        case noVideoTrack
        case tooFewDetections(Int)
        case processingFailed(String)

        var errorDescription: String? {
            switch self {
            case .noVideoTrack:
                return "Could not read the video track. Try an MP4 or MOV file."
            case .tooFewDetections(let n):
                return "Only \(n) trajectory points detected. Try filming against a plain background with good lighting."
            case .processingFailed(let msg):
                return "Processing failed: \(msg)"
            }
        }
    }

    // MARK: - Public entry point

    func analyze(url: URL, progressHandler: @escaping (Double) -> Void) async throws -> FlightMetrics {

        let asset = AVAsset(url: url)

        // Prefer VNDetectTrajectoriesRequest — Apple's purpose-built API for
        // tracking objects moving in parabolic paths (perfect for paper airplanes)
        do {
            let points = try await detectTrajectoryWithVision(asset: asset, progressHandler: progressHandler)
            if points.count >= 5 {
                return buildMetrics(from: points)
            }
        } catch {
            // Fall through to pixel-diff fallback
        }

        await MainActor.run { progressHandler(0.3) }

        // Fallback: frame-by-frame pixel brightness tracking
        // (same algorithm verified 9/9 in Python tests)
        let points = try await detectTrajectoryWithPixelDiff(asset: asset, progressHandler: progressHandler)
        guard points.count >= 4 else {
            throw AnalysisError.tooFewDetections(points.count)
        }
        return buildMetrics(from: points)
    }

    // MARK: - Method 1: VNDetectTrajectoriesRequest (iOS 14+)

    private func detectTrajectoryWithVision(asset: AVAsset, progressHandler: @escaping (Double) -> Void) async throws -> [FlightPoint] {

        let videoProcessor = VNVideoProcessor(url: (asset as? AVURLAsset)?.url ?? URL(fileURLWithPath: ""))

        var collectedPoints: [FlightPoint] = []
        var processingError: Error? = nil
        let duration = try await asset.load(.duration).seconds

        let request = VNDetectTrajectoriesRequest(frameAnalysisSpacing: .zero, trajectoryLength: 5) { req, err in
            if let err = err { processingError = err; return }
            guard let results = req.results as? [VNTrajectoryObservation] else { return }
            for obs in results {
                for pt in obs.detectedPoints {
                    // VNPoint is normalised: 0,0 = bottom-left → flip y for our convention
                    collectedPoints.append(FlightPoint(
                        x: pt.x,
                        y: 1.0 - pt.y,
                        time: pt.x * duration  // approximate; we use relative position
                    ))
                }
            }
        }

        try videoProcessor.add(request, withProcessingOptions: [:])

        let durationCM = try await asset.load(.duration)
        try videoProcessor.analyze(CMTimeRange(start: .zero, duration: durationCM))

        if let err = processingError { throw err }

        await MainActor.run { progressHandler(0.6) }
        return collectedPoints
    }

    // MARK: - Method 2: Pixel-diff tracking (reliable fallback)

    private func detectTrajectoryWithPixelDiff(asset: AVAsset, progressHandler: @escaping (Double) -> Void) async throws -> [FlightPoint] {

        guard let videoTrack = try await asset.loadTracks(withMediaType: .video).first else {
            throw AnalysisError.noVideoTrack
        }

        let duration = try await asset.load(.duration).seconds
        let naturalSize = try await videoTrack.load(.naturalSize)
        let preferredTransform = try await videoTrack.load(.preferredTransform)
        let videoSize = naturalSize.applying(preferredTransform)
        let W = abs(videoSize.width)
        let H = abs(videoSize.height)

        let generator = AVAssetImageGenerator(asset: asset)
        generator.appliesPreferredTrackTransform = true
        generator.requestedTimeToleranceBefore = CMTime(value: 1, timescale: 30)
        generator.requestedTimeToleranceAfter  = CMTime(value: 1, timescale: 30)

        // Capture every 0.2 seconds
        let interval = 0.2
        var times: [CMTime] = []
        var t = 0.0
        while t < duration {
            times.append(CMTime(seconds: t, preferredTimescale: 600))
            t += interval
        }

        // Extract frames
        var rawFrames: [(image: CGImage, time: Double)] = []
        for (idx, time) in times.enumerated() {
            if let cgImage = try? generator.copyCGImage(at: time, actualTime: nil) {
                rawFrames.append((cgImage, time.seconds))
            }
            await MainActor.run { progressHandler(0.3 + 0.3 * Double(idx) / Double(times.count)) }
        }

        guard rawFrames.count >= 4 else {
            throw AnalysisError.tooFewDetections(rawFrames.count)
        }

        // Convert to RGBA pixel buffers
        let targetW = 320, targetH = 180   // downsample for speed
        let colorSpace = CGColorSpaceCreateDeviceRGB()
        let bitmapInfo = CGImageAlphaInfo.premultipliedLast.rawValue

        func toRGBA(_ cgImage: CGImage) -> [UInt8]? {
            var data = [UInt8](repeating: 0, count: targetW * targetH * 4)
            guard let ctx = CGContext(data: &data, width: targetW, height: targetH,
                                     bitsPerComponent: 8, bytesPerRow: targetW * 4,
                                     space: colorSpace, bitmapInfo: bitmapInfo) else { return nil }
            ctx.draw(cgImage, in: CGRect(x: 0, y: 0, width: targetW, height: targetH))
            return data
        }

        guard let bgPixels = toRGBA(rawFrames[0].image) else {
            throw AnalysisError.processingFailed("Could not convert background frame")
        }

        // Detect plane in each frame
        var raw: [(point: FlightPoint?, time: Double)] = []
        for (idx, frame) in rawFrames.enumerated() {
            guard let pixels = toRGBA(frame.image) else { raw.append((nil, frame.time)); continue }
            let pt = findPlane(frame: pixels, bg: bgPixels, W: targetW, H: targetH)
            raw.append((pt.map { FlightPoint(x: $0.x, y: $0.y, time: frame.time) }, frame.time))
            await MainActor.run { progressHandler(0.6 + 0.3 * Double(idx) / Double(rawFrames.count)) }
        }

        // Throw detection — discard pre-throw frames
        let dets = raw.compactMap { $0.point }
        guard dets.count >= 2 else { return dets }

        var dists: [(idx: Int, d: Double)] = []
        for i in 1..<raw.count {
            if let a = raw[i-1].point, let b = raw[i].point {
                let dx = b.x - a.x, dy = b.y - a.y
                dists.append((i, sqrt(dx*dx + dy*dy)))
            } else {
                dists.append((i, 0))
            }
        }
        let earlyCount = max(dists.count / 4, 1)
        let earlyMean = dists.prefix(earlyCount).reduce(0) { $0 + $1.d } / Double(earlyCount)
        let thresh = max(earlyMean * 4, 0.03)
        var throwIdx = 0
        for d in dists { if d.d > thresh { throwIdx = d.idx; break } }

        return raw.dropFirst(throwIdx).compactMap { $0.point }
    }

    // MARK: - Pixel-diff plane finder (positive diff only — verified 9/9 paths)

    private func findPlane(frame: [UInt8], bg: [UInt8], W: Int, H: Int) -> (x: Double, y: Double)? {
        let THRESH = 75
        let MIN_BLOB = 40
        let GRID = 8
        let cellW = max(W / GRID, 1)
        let cellH = max(H / GRID, 1)

        var cells   = [Int](repeating: 0, count: GRID * GRID)
        var cellSX  = [Int](repeating: 0, count: GRID * GRID)
        var cellSY  = [Int](repeating: 0, count: GRID * GRID)
        var total   = 0

        for y in 0..<H {
            for x in 0..<W {
                let i = (y * W + x) * 4
                let dr = max(Int(frame[i])   - Int(bg[i]),   0)
                let dg = max(Int(frame[i+1]) - Int(bg[i+1]), 0)
                let db = max(Int(frame[i+2]) - Int(bg[i+2]), 0)
                if dr + dg + db > THRESH {
                    let cx = min(x / cellW, GRID - 1)
                    let cy = min(y / cellH, GRID - 1)
                    let ci = cy * GRID + cx
                    cells[ci]  += 1
                    cellSX[ci] += x
                    cellSY[ci] += y
                    total += 1
                }
            }
        }

        guard total >= MIN_BLOB else { return nil }

        let maxIdx = cells.indices.max(by: { cells[$0] < cells[$1] })!
        guard cells[maxIdx] >= MIN_BLOB / 4 else { return nil }

        let pCx = maxIdx % GRID, pCy = maxIdx / GRID
        var sx = 0, sy = 0, sc = 0
        for cy in 0..<GRID {
            for cx in 0..<GRID {
                if abs(cx - pCx) <= 2 && abs(cy - pCy) <= 2 {
                    let ci = cy * GRID + cx
                    sx += cellSX[ci]; sy += cellSY[ci]; sc += cells[ci]
                }
            }
        }
        guard sc >= MIN_BLOB else { return nil }

        return (x: Double(sx) / Double(sc) / Double(W),
                y: Double(sy) / Double(sc) / Double(H))
    }

    // MARK: - Metrics computation

    private func buildMetrics(from points: [FlightPoint]) -> FlightMetrics {
        let n = points.count
        let xs = points.map(\.x)
        let ys = points.map(\.y)

        let startX = xs[0], endX = xs[n - 1]
        let lateralDrift = xs.map { abs($0 - startX) }.max()! * 100
        let driftDir: FlightMetrics.DriftDirection =
            endX > startX + 0.02 ? .right :
            endX < startX - 0.02 ? .left : .straight

        let verticalDrop = (ys[n - 1] - ys[0]) * 100

        let xD = zip(xs.dropFirst(), xs).map { $0 - $1 }
        let xMu = xD.reduce(0, +) / Double(xD.count)
        let wobble = sqrt(xD.map { ($0 - xMu) * ($0 - xMu) }.reduce(0, +) / Double(xD.count)) * 1000

        let climbFrames = zip(ys.dropFirst(), ys).filter { $0 < $1 }.count
        let climbRatio = Double(climbFrames) / Double(n - 1)

        let hangTime = points.last!.time - points.first!.time

        return FlightMetrics(
            points: points,
            lateralDrift: lateralDrift,
            driftDirection: driftDir,
            verticalDrop: verticalDrop,
            wobble: wobble,
            climbRatio: climbRatio,
            hangTime: hangTime
        )
    }
}

// MARK: - Flight Classifier

struct FlightClassifier {
    static func classify(_ m: FlightMetrics) -> FlightPath {
        let climbing   = m.verticalDrop < -5
        let level      = m.verticalDrop >= -5 && m.verticalDrop <= 15
        let descending = m.verticalDrop > 15
        let tooFast    = climbing && m.climbRatio > 0.72 && m.lateralDrift < 8
        let dL = m.driftDirection == .left  && m.lateralDrift > 5
        let dR = m.driftDirection == .right && m.lateralDrift > 5

        switch true {
        case tooFast:              return .upTooFast
        case climbing && dL:       return .upAndLeft
        case climbing && dR:       return .upAndRight
        case level    && dL:       return .levelLeft
        case level    && dR:       return .levelRight
        case descending && dL:     return .downAndLeft
        case descending && dR:     return .downAndRight
        case descending:           return .downButStraight
        default:                   return .good
        }
    }
}
