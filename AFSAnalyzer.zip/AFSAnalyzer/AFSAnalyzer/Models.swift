import Foundation
import CoreGraphics

// MARK: - Flight Data

struct FlightPoint {
    let x: Double   // normalised 0–1, 0 = left edge
    let y: Double   // normalised 0–1, 0 = top
    let time: Double
}

struct FlightMetrics {
    let points: [FlightPoint]
    let lateralDrift: Double      // % of frame width
    let driftDirection: DriftDirection
    let verticalDrop: Double      // % of frame height — positive = fell, negative = climbed
    let wobble: Double
    let climbRatio: Double
    let hangTime: Double

    enum DriftDirection {
        case left, right, straight
        var label: String {
            switch self { case .left: return "LEFT"; case .right: return "RIGHT"; case .straight: return "STRAIGHT" }
        }
    }
}

// MARK: - Flight Path Classification

enum FlightPath: String, CaseIterable {
    case upTooFast       = "UP_TOO_FAST"
    case upAndLeft       = "UP_AND_LEFT"
    case upAndRight      = "UP_AND_RIGHT"
    case levelLeft       = "LEVEL_LEFT"
    case levelRight      = "LEVEL_RIGHT"
    case downAndLeft     = "DOWN_AND_LEFT"
    case downAndRight    = "DOWN_AND_RIGHT"
    case downButStraight = "DOWN_BUT_STRAIGHT"
    case good            = "GOOD"

    var label: String {
        switch self {
        case .upTooFast:       return "✈  UP TOO FAST"
        case .upAndLeft:       return "↖  UP AND LEFT"
        case .upAndRight:      return "↗  UP AND RIGHT"
        case .levelLeft:       return "←  LEVEL LEFT"
        case .levelRight:      return "→  LEVEL RIGHT"
        case .downAndLeft:     return "↙  DOWN AND LEFT"
        case .downAndRight:    return "↘  DOWN AND RIGHT"
        case .downButStraight: return "↓  DOWN BUT STRAIGHT"
        case .good:            return "✓  GREAT FLIGHT"
        }
    }

    var score: Int {
        switch self {
        case .upTooFast:                       return 55
        case .upAndLeft, .upAndRight:          return 50
        case .levelLeft, .levelRight:          return 48
        case .downButStraight:                 return 32
        case .downAndLeft, .downAndRight:      return 30
        case .good:                            return 92
        }
    }

    var steps: [FeedbackStep] {
        switch self {
        case .upTooFast:
            return [
                .init("Try lowering the rear flaps a bit. Ensure the paper clip is entirely inserted into the keel.", indent: 0, severity: .warning)
            ]
        case .upAndLeft:
            return [
                .init("Try decreasing the size of the pocket under the LEFT side wing.", indent: 0, severity: .warning),
                .init("Try increasing the size of the pocket of the RIGHT side wing.", indent: 1, label: "DIDN'T WORK?", severity: .bad)
            ]
        case .upAndRight:
            return [
                .init("Try decreasing the size of the pocket under the RIGHT side wing.", indent: 0, severity: .warning),
                .init("Try increasing the size of the pocket of the LEFT side wing.", indent: 1, label: "DIDN'T WORK?", severity: .bad)
            ]
        case .levelLeft:
            return [
                .init("Check the tail to ensure it is straight. The trailing edge of the tail is most likely bent to the LEFT in some way.", indent: 0, severity: .warning),
                .init("Try decreasing the size of the pocket under the LEFT side wing.", indent: 1, label: "DIDN'T WORK?", severity: .warning),
                .init("Try increasing the size of the pocket of the RIGHT side wing.", indent: 2, label: "STILL DIDN'T WORK?", severity: .bad)
            ]
        case .levelRight:
            return [
                .init("Check the tail to ensure it is straight. The trailing edge of the tail is most likely bent to the RIGHT in some way.", indent: 0, severity: .warning),
                .init("Try decreasing the size of the pocket under the RIGHT side wing.", indent: 1, label: "DIDN'T WORK?", severity: .warning),
                .init("Try increasing the size of the pocket of the LEFT side wing.", indent: 2, label: "STILL DIDN'T WORK?", severity: .bad)
            ]
        case .downAndLeft:
            return [
                .init("First focus on making the plane go up, then tackle going straight. If the plane is diving downward check to ensure: the wing pockets are opened, the flaps on the rear of the wings are up, the paper clip is not too far forward — it should be just inside the keel.", indent: 0, severity: .bad),
                .init("Try decreasing the size of the pocket under the LEFT side wing.", indent: 1, label: "MY PLANE IS GOING UP BUT STILL LEFT?", severity: .warning),
                .init("Try increasing the size of the pocket of the RIGHT side wing.", indent: 2, label: "DIDN'T WORK?", severity: .bad),
                .init("Recheck the preflight section — there might be something you missed.", indent: 1, label: "STILL NO JOY AT ALL?", severity: .bad)
            ]
        case .downAndRight:
            return [
                .init("First focus on making the plane go up, then tackle going straight. If the plane is diving downward check to ensure: the wing pockets are opened, the flaps on the rear of the wings are up, the paper clip is not too far forward — it should be just inside the keel.", indent: 0, severity: .bad),
                .init("Try decreasing the size of the pocket under the RIGHT side wing.", indent: 1, label: "MY PLANE IS GOING UP BUT STILL RIGHT?", severity: .warning),
                .init("Try increasing the size of the pocket of the LEFT side wing.", indent: 2, label: "DIDN'T WORK?", severity: .bad),
                .init("Recheck the preflight section — there might be something you missed.", indent: 1, label: "STILL NO JOY AT ALL?", severity: .bad)
            ]
        case .downButStraight:
            return [
                .init("Check to ensure: the wing pockets are opened the correct amount (see preflight), the flaps on the rear of the wings are up, the paper clip is not too far forward — it should be just inside the keel.", indent: 0, severity: .bad),
                .init("Recheck the preflight section — there might be something you missed.", indent: 1, label: "STILL NO JOY?", severity: .bad)
            ]
        case .good:
            return [
                .init("Great flight! The plane flew straight and true. Keep experimenting with launch force and angle to maximise distance.", indent: 0, severity: .ok)
            ]
        }
    }
}

// MARK: - Feedback Step

struct FeedbackStep: Identifiable {
    let id = UUID()
    let message: String
    let indent: Int
    let label: String?
    let severity: Severity

    enum Severity { case ok, warning, bad }

    init(_ message: String, indent: Int, label: String? = nil, severity: Severity) {
        self.message  = message
        self.indent   = indent
        self.label    = label
        self.severity = severity
    }
}
