import SwiftUI

struct ResultsView: View {
    let metrics: FlightMetrics
    let flightPath: FlightPath
    let onReset: () -> Void

    private let cyan   = Color(red: 0, green: 0.831, blue: 1)
    private let green  = Color(red: 0, green: 0.910, blue: 0.478)
    private let amber  = Color(red: 1, green: 0.722, blue: 0)
    private let red    = Color(red: 1, green: 0.267, blue: 0.333)
    private let panel  = Color(red: 0.043, green: 0.082, blue: 0.145)
    private let border = Color(red: 0.082, green: 0.161, blue: 0.29)

    var body: some View {
        VStack(spacing: 14) {

            // ── Score ───────────────────────────────────────────────
            scoreCard

            // ── Trajectory ──────────────────────────────────────────
            VStack(alignment: .leading, spacing: 8) {
                panelLabel("Flight Trajectory (behind-view)")
                TrajectoryView(points: metrics.points)
                    .frame(height: 160)
                    .background(Color.black.opacity(0.4))
                    .cornerRadius(4)
            }
            .padding(14)
            .background(panel)
            .cornerRadius(8)
            .overlay(RoundedRectangle(cornerRadius: 8).strokeBorder(border, lineWidth: 1))

            // ── Telemetry ───────────────────────────────────────────
            VStack(alignment: .leading, spacing: 8) {
                panelLabel("Telemetry")
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 8), count: 3), spacing: 8) {
                    metricCell("DRIFT",    driftValue,     driftColor)
                    metricCell("HANG",     "\(String(format: "%.1f", metrics.hangTime))s", metrics.hangTime > 2 ? green : metrics.hangTime > 0.5 ? amber : red)
                    metricCell("V.DROP",   "\(Int(abs(metrics.verticalDrop)))%", metrics.verticalDrop < 5 ? green : metrics.verticalDrop < 30 ? amber : red)
                    metricCell("WOBBLE",   wobbleLabel,    wobbleColor)
                    metricCell("CLIMB",    "\(Int(metrics.climbRatio * 100))%", metrics.climbRatio > 0.4 ? green : metrics.climbRatio > 0.15 ? amber : red)
                    metricCell("POINTS",   "\(metrics.points.count)", metrics.points.count > 16 ? green : metrics.points.count > 6 ? amber : red)
                }
            }
            .padding(14)
            .background(panel)
            .cornerRadius(8)
            .overlay(RoundedRectangle(cornerRadius: 8).strokeBorder(border, lineWidth: 1))

            // ── Diagnosis ───────────────────────────────────────────
            VStack(alignment: .leading, spacing: 10) {
                panelLabel("Flight Path Diagnosis")

                Text("DETECTED: \(flightPath.label)")
                    .font(.system(size: 10, design: .monospaced))
                    .foregroundColor(cyan)
                    .kerning(2)

                ForEach(flightPath.steps) { step in
                    stepView(step)
                }
            }
            .padding(14)
            .background(panel)
            .cornerRadius(8)
            .overlay(RoundedRectangle(cornerRadius: 8).strokeBorder(border, lineWidth: 1))

            // ── Analyse another ─────────────────────────────────────
            Button(action: onReset) {
                Text("ANALYSE ANOTHER FLIGHT")
                    .font(.system(size: 12, design: .monospaced))
                    .foregroundColor(Color(red: 0.016, green: 0.031, blue: 0.059))
                    .kerning(3)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(cyan)
                    .cornerRadius(4)
            }
            .buttonStyle(.plain)
        }
    }

    // MARK: - Score Card

    private var scoreCard: some View {
        HStack(spacing: 18) {
            ZStack {
                Circle()
                    .stroke(scoreColor.opacity(0.12), lineWidth: 5)
                Circle()
                    .trim(from: 0, to: CGFloat(flightPath.score) / 100)
                    .stroke(scoreColor, style: StrokeStyle(lineWidth: 5, lineCap: .round))
                    .rotationEffect(.degrees(-90))
                    .animation(.easeInOut(duration: 0.8), value: flightPath.score)
                Text("\(flightPath.score)")
                    .font(.system(size: 34, design: .monospaced))
                    .foregroundColor(scoreColor)
            }
            .frame(width: 70, height: 70)

            VStack(alignment: .leading, spacing: 4) {
                Text("\(flightPath.score)")
                    .font(.system(size: 36, design: .monospaced))
                    .foregroundColor(scoreColor)
                Text("FLIGHT SCORE")
                    .font(.system(size: 9, design: .monospaced))
                    .foregroundColor(Color(white: 0.35))
                    .kerning(3)
            }
            Spacer()
        }
        .padding(16)
        .background(panel)
        .cornerRadius(8)
        .overlay(RoundedRectangle(cornerRadius: 8).strokeBorder(border, lineWidth: 1))
    }

    // MARK: - Step View

    private func stepView(_ step: FeedbackStep) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            if let label = step.label {
                Text("▸ \(label)")
                    .font(.system(size: 9, design: .monospaced))
                    .foregroundColor(amber)
                    .kerning(2)
            }
            HStack(alignment: .top, spacing: 10) {
                Text(stepIcon(step.severity))
                    .font(.system(size: 14))
                Text(step.message)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(stepColor(step.severity))
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(11)
            .background(stepBg(step.severity))
            .cornerRadius(4)
            .overlay(
                RoundedRectangle(cornerRadius: 4)
                    .strokeBorder(stepColor(step.severity).opacity(0.25), lineWidth: 1)
            )
        }
        .padding(.leading, CGFloat(step.indent) * 20)
    }

    // MARK: - Helpers

    private func panelLabel(_ text: String) -> some View {
        Text(text.uppercased())
            .font(.system(size: 9, design: .monospaced))
            .foregroundColor(Color(white: 0.35))
            .kerning(3)
    }

    private func metricCell(_ label: String, _ value: String, _ color: Color) -> some View {
        VStack(spacing: 3) {
            Text(value)
                .font(.system(size: 18, design: .monospaced))
                .foregroundColor(color)
            Text(label)
                .font(.system(size: 8, design: .monospaced))
                .foregroundColor(Color(white: 0.35))
                .kerning(2)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 10)
        .background(Color(red: 0.016, green: 0.031, blue: 0.059))
        .cornerRadius(4)
        .overlay(RoundedRectangle(cornerRadius: 4).strokeBorder(border, lineWidth: 1))
    }

    private func stepIcon(_ s: FeedbackStep.Severity) -> String {
        switch s { case .ok: return "✓"; case .warning: return "△"; case .bad: return "✗" }
    }
    private func stepColor(_ s: FeedbackStep.Severity) -> Color {
        switch s { case .ok: return green; case .warning: return amber; case .bad: return red }
    }
    private func stepBg(_ s: FeedbackStep.Severity) -> Color {
        switch s {
        case .ok:      return green.opacity(0.07)
        case .warning: return amber.opacity(0.07)
        case .bad:     return red.opacity(0.07)
        }
    }

    private var scoreColor: Color {
        flightPath.score >= 75 ? green : flightPath.score >= 50 ? amber : red
    }

    private var driftValue: String {
        let dir = metrics.driftDirection == .straight ? "" : " \(metrics.driftDirection.label.prefix(1))"
        return "\(Int(metrics.lateralDrift))%\(dir)"
    }
    private var driftColor: Color {
        metrics.lateralDrift < 5 ? green : metrics.lateralDrift < 12 ? amber : red
    }
    private var wobbleLabel: String {
        metrics.wobble < 7 ? "LOW" : metrics.wobble < 14 ? "MED" : "HIGH"
    }
    private var wobbleColor: Color {
        metrics.wobble < 7 ? green : metrics.wobble < 14 ? amber : red
    }
}
