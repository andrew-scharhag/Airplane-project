import SwiftUI
import PhotosUI

struct ContentView: View {
    @State private var selectedItem: PhotosPickerItem?
    @State private var videoURL: URL?
    @State private var phase: Phase = .idle
    @State private var progress: Double = 0
    @State private var metrics: FlightMetrics?
    @State private var flightPath: FlightPath?
    @State private var errorMessage: String?

    enum Phase {
        case idle, analysing, done, error
    }

    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 0.016, green: 0.031, blue: 0.059)
                    .ignoresSafeArea()

                ScrollView {
                    VStack(spacing: 16) {

                        // ── Pick video ──────────────────────────────────
                        if phase == .idle || phase == .error {
                            UploadCard(selectedItem: $selectedItem)
                                .onChange(of: selectedItem) { _, item in
                                    guard let item else { return }
                                    loadVideo(from: item)
                                }
                        }

                        // ── Progress ────────────────────────────────────
                        if phase == .analysing {
                            AnalysingCard(progress: progress)
                        }

                        // ── Error ───────────────────────────────────────
                        if phase == .error, let msg = errorMessage {
                            ErrorCard(message: msg) {
                                phase = .idle
                                selectedItem = nil
                                errorMessage = nil
                            }
                        }

                        // ── Results ─────────────────────────────────────
                        if phase == .done, let m = metrics, let fp = flightPath {
                            ResultsView(metrics: m, flightPath: fp) {
                                phase = .idle
                                selectedItem = nil
                                metrics = nil
                                flightPath = nil
                            }
                        }

                        Spacer(minLength: 40)
                    }
                    .padding(16)
                }
            }
            .navigationTitle("")
            .toolbar {
                ToolbarItem(placement: .principal) {
                    HStack(spacing: 10) {
                        Text("AFS")
                            .font(.system(.headline, design: .monospaced))
                            .foregroundColor(Color(red: 0, green: 0.831, blue: 1))
                        Text("PAPER AIRPLANE ANALYZER")
                            .font(.system(size: 10, design: .monospaced))
                            .foregroundColor(Color(white: 0.4))
                            .kerning(2)
                    }
                }
            }
            .toolbarBackground(Color(red: 0.016, green: 0.031, blue: 0.059), for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
        }
    }

    // MARK: - Load & Analyse

    private func loadVideo(from item: PhotosPickerItem) {
        phase = .analysing
        progress = 0

        Task {
            do {
                // Copy to temp file
                guard let data = try await item.loadTransferable(type: Data.self) else {
                    throw AnalysisEngine.AnalysisError.processingFailed("Could not load video data")
                }
                let tempURL = FileManager.default.temporaryDirectory
                    .appendingPathComponent(UUID().uuidString)
                    .appendingPathExtension("mov")
                try data.write(to: tempURL)

                let engine = AnalysisEngine()
                let result = try await engine.analyze(url: tempURL) { p in
                    Task { @MainActor in progress = p }
                }

                try? FileManager.default.removeItem(at: tempURL)

                await MainActor.run {
                    metrics = result
                    flightPath = FlightClassifier.classify(result)
                    phase = .done
                }
            } catch {
                await MainActor.run {
                    errorMessage = error.localizedDescription
                    phase = .error
                }
            }
        }
    }
}

// MARK: - Upload Card

struct UploadCard: View {
    @Binding var selectedItem: PhotosPickerItem?

    var body: some View {
        PhotosPicker(selection: $selectedItem, matching: .videos) {
            VStack(spacing: 16) {
                Text("✈")
                    .font(.system(size: 52))
                    .shadow(color: Color(red: 0, green: 0.831, blue: 1).opacity(0.4), radius: 16)

                Text("SELECT FLIGHT VIDEO")
                    .font(.system(size: 15, weight: .bold, design: .monospaced))
                    .foregroundColor(Color(red: 0, green: 0.831, blue: 1))
                    .kerning(3)

                Text("film from behind the thrower\nmp4 · mov · plain background")
                    .font(.system(size: 10, design: .monospaced))
                    .foregroundColor(Color(white: 0.35))
                    .kerning(1)
                    .multilineTextAlignment(.center)
                    .lineSpacing(4)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 44)
            .background(Color(red: 0.043, green: 0.082, blue: 0.145))
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .strokeBorder(style: StrokeStyle(lineWidth: 1, dash: [6]))
                    .foregroundColor(Color(red: 0.082, green: 0.161, blue: 0.29))
            )
            .cornerRadius(8)
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Analysing Card

struct AnalysingCard: View {
    let progress: Double
    @State private var dotCount = 1

    var body: some View {
        VStack(spacing: 20) {
            Text("ANALYSING" + String(repeating: ".", count: dotCount))
                .font(.system(size: 13, design: .monospaced))
                .foregroundColor(Color(red: 1, green: 0.722, blue: 0))
                .kerning(3)
                .onAppear {
                    Timer.scheduledTimer(withTimeInterval: 0.4, repeats: true) { _ in
                        dotCount = dotCount % 3 + 1
                    }
                }

            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 2)
                        .fill(Color(white: 0.1))
                        .frame(height: 3)
                    RoundedRectangle(cornerRadius: 2)
                        .fill(Color(red: 0, green: 0.831, blue: 1))
                        .frame(width: geo.size.width * max(progress, 0.05), height: 3)
                        .shadow(color: Color(red: 0, green: 0.831, blue: 1).opacity(0.6), radius: 4)
                        .animation(.easeInOut(duration: 0.3), value: progress)
                }
            }
            .frame(height: 3)

            Text("Running Vision trajectory detection...")
                .font(.system(size: 10, design: .monospaced))
                .foregroundColor(Color(white: 0.35))
                .kerning(1)
        }
        .padding(20)
        .background(Color(red: 0.043, green: 0.082, blue: 0.145))
        .cornerRadius(8)
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .strokeBorder(Color(red: 0.082, green: 0.161, blue: 0.29), lineWidth: 1)
        )
    }
}

// MARK: - Error Card

struct ErrorCard: View {
    let message: String
    let onRetry: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("❌ ANALYSIS FAILED")
                .font(.system(size: 11, design: .monospaced))
                .foregroundColor(Color(red: 1, green: 0.267, blue: 0.333))
                .kerning(2)
            Text(message)
                .font(.system(size: 13))
                .foregroundColor(Color(white: 0.7))

            Button("TRY AGAIN") { onRetry() }
                .font(.system(size: 12, design: .monospaced))
                .foregroundColor(Color(red: 0, green: 0.831, blue: 1))
                .kerning(2)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(Color(red: 0.043, green: 0.082, blue: 0.145))
        .cornerRadius(8)
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .strokeBorder(Color(red: 1, green: 0.267, blue: 0.333).opacity(0.4), lineWidth: 1)
        )
    }
}
