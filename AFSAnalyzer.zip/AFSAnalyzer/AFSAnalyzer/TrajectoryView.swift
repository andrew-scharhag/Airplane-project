import SwiftUI

struct TrajectoryView: View {
    let points: [FlightPoint]

    var body: some View {
        Canvas { ctx, size in
            guard points.count >= 2 else {
                var text = AttributedString("INSUFFICIENT TRACKING DATA")
                text.font = .system(size: 11, design: .monospaced)
                text.foregroundColor = Color(red: 1, green: 0.267, blue: 0.333).opacity(0.7)
                ctx.draw(Text(text), at: CGPoint(x: size.width/2, y: size.height/2), anchor: .center)
                return
            }

            let pad: CGFloat = 28
            let w = size.width  - pad * 2
            let h = size.height - pad * 2
            let ox = size.width  / 2
            let oy = size.height / 2

            // Behind-view: x = lateral deviation, y = altitude (up = positive)
            let startX = points[0].x, startY = points[0].y
            let dxs = points.map { $0.x - startX }
            let dys = points.map { -($0.y - startY) } // invert: up = positive

            let maxDx = max(dxs.map { abs($0) }.max() ?? 0.05, 0.05)
            let maxDy = max(dys.map { abs($0) }.max() ?? 0.05, 0.05)
            let scale = min(w / 2 / maxDx, h / 2 / maxDy) * 0.82

            func toCanvas(_ dx: Double, _ dy: Double) -> CGPoint {
                CGPoint(x: ox + dx * scale, y: oy - dy * scale)
            }

            // Grid
            let gridColor = Color(red: 0, green: 0.831, blue: 1).opacity(0.06)
            for i in -3...3 {
                let fi = CGFloat(i)
                ctx.stroke(Path { p in
                    p.move(to: CGPoint(x: ox + fi * (w / 6), y: pad))
                    p.addLine(to: CGPoint(x: ox + fi * (w / 6), y: pad + h))
                }, with: .color(gridColor))
                ctx.stroke(Path { p in
                    p.move(to: CGPoint(x: pad, y: oy + fi * (h / 4)))
                    p.addLine(to: CGPoint(x: pad + w, y: oy + fi * (h / 4)))
                }, with: .color(gridColor))
            }

            // Crosshair
            let crossColor = Color(red: 0, green: 0.831, blue: 1).opacity(0.18)
            ctx.stroke(Path { p in
                p.move(to: CGPoint(x: ox, y: pad))
                p.addLine(to: CGPoint(x: ox, y: pad + h))
            }, with: .color(crossColor), style: StrokeStyle(lineWidth: 1, dash: [4, 4]))
            ctx.stroke(Path { p in
                p.move(to: CGPoint(x: pad, y: oy))
                p.addLine(to: CGPoint(x: pad + w, y: oy))
            }, with: .color(crossColor), style: StrokeStyle(lineWidth: 1, dash: [4, 4]))

            // Axis labels
            let dimColor = Color(red: 0.227, green: 0.353, blue: 0.478).opacity(0.8)
            func label(_ text: String, at pt: CGPoint) {
                var attr = AttributedString(text)
                attr.font = .system(size: 9, design: .monospaced)
                attr.foregroundColor = dimColor
                ctx.draw(Text(attr), at: pt, anchor: .center)
            }
            label("LEFT",  at: CGPoint(x: pad + 20, y: oy - 6))
            label("RIGHT", at: CGPoint(x: pad + w - 20, y: oy - 6))
            label("UP",    at: CGPoint(x: ox, y: pad + 8))
            label("DOWN",  at: CGPoint(x: ox, y: pad + h - 6))

            // Flight path — colour shifts cyan→amber as flight progresses
            for i in 1..<points.count {
                let t = Double(i) / Double(points.count)
                let r = t
                let g = (212.0 - t * 28.0) / 255.0
                let b = (1.0 - t)
                let color = Color(red: r, green: g, blue: b)
                let p0 = toCanvas(dxs[i-1], dys[i-1])
                let p1 = toCanvas(dxs[i],   dys[i])
                ctx.stroke(Path { p in
                    p.move(to: p0); p.addLine(to: p1)
                }, with: .color(color), style: StrokeStyle(lineWidth: 2.5, lineCap: .round))
            }

            // Launch dot (green)
            let sp = toCanvas(0, 0)
            ctx.fill(Circle().path(in: CGRect(x: sp.x-5, y: sp.y-5, width: 10, height: 10)),
                     with: .color(Color(red: 0, green: 0.910, blue: 0.478)))

            // Land dot (red)
            let ep = toCanvas(dxs.last!, dys.last!)
            ctx.fill(Circle().path(in: CGRect(x: ep.x-5, y: ep.y-5, width: 10, height: 10)),
                     with: .color(Color(red: 1, green: 0.267, blue: 0.333)))

            // Labels
            func smallLabel(_ text: String, at pt: CGPoint, color: Color) {
                var attr = AttributedString(text)
                attr.font = .system(size: 9, design: .monospaced)
                attr.foregroundColor = color
                ctx.draw(Text(attr), at: CGPoint(x: pt.x + 8, y: pt.y), anchor: .leading)
            }
            smallLabel("LAUNCH", at: sp, color: Color(red: 0, green: 0.910, blue: 0.478).opacity(0.8))
            smallLabel("LAND",   at: ep, color: Color(red: 1, green: 0.267, blue: 0.333).opacity(0.8))
        }
    }
}
